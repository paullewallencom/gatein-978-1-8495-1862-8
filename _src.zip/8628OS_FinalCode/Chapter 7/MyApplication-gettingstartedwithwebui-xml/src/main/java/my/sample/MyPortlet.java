package my.sample;

import org.exoplatform.webui.core.UIPortletApplication;

public class MyPortlet extends UIPortletApplication {
	public MyPortlet() throws Exception {

	}
}
