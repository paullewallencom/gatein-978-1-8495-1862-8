package my.gatein;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import java.util.ServiceLoader;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.RepositoryFactory;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.apache.jackrabbit.commons.JndiRepositoryFactory;

public class RemoteJackrabbitPortlet extends GenericPortlet {

	@Override
	protected void doView(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {

		if (request.getUserPrincipal() != null) {
			response.setContentType("text/html");
			PrintWriter writer = response.getWriter();

			writer.print("<p><a href='" + response.createActionURL() + "'>"
					+ "Remote controller Jackrabbit</a></p>");

			//
			writer.close();
		}
	}

	@Override
	public void processAction(ActionRequest request, ActionResponse response)
			throws PortletException, IOException {

		Properties parameters = new Properties();
		parameters.put("org.apache.jackrabbit.repository.uri",
				"jndi:/jackrabbit");
		parameters
				.put("java.naming.factory.initial",
						"org.apache.jackrabbit.core.jndi.provider.DummyInitialContextFactory");
		parameters.put("java.naming.provider.url", "localhost:1099");

		Repository repository = null;

		for (RepositoryFactory factory : ServiceLoader
				.load(RepositoryFactory.class)) {
			if (factory instanceof JndiRepositoryFactory)
				try {
					repository = factory.getRepository(parameters);
					Session session = (Session) repository.login("default");
					Node root = (Node) session.getRootNode();
					printAllNodes(root, "");

				} catch (RepositoryException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void printAllNodes(Node root, String space)
			throws RepositoryException {
		NodeIterator nodeIterator = (NodeIterator) root.getNodes();
		while (nodeIterator.hasNext()) {
			Node node = (Node) nodeIterator.nextNode();
			System.out.println(space + node);
			System.out.println();
			PropertyIterator pi = node.getProperties();
			while (pi.hasNext()) {
				Property property = pi.nextProperty();
				System.out
						.println(space
								+ "------------------------------------------------------");
				System.out.print(space + property.getName() + " - ");
				try {
					System.out.println(property.getValue().getString());
				} catch (ValueFormatException e) {
					for (Value value : property.getValues())
						System.out.print(value.getString() + " - ");
					System.out.println();
				}
			}
			printAllNodes(node, space + "   ");
		}
	}
}