package my.gatein;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.modeshape.web.jcr.rest.client.IRestClient;
import org.modeshape.web.jcr.rest.client.domain.QueryRow;
import org.modeshape.web.jcr.rest.client.domain.Repository;
import org.modeshape.web.jcr.rest.client.domain.Server;
import org.modeshape.web.jcr.rest.client.domain.Workspace;
import org.modeshape.web.jcr.rest.client.json.JsonRestClient;

public class RemoteModeshapePortlet extends GenericPortlet {

	@Override
	protected void doView(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {

		if (request.getUserPrincipal() != null) {
			response.setContentType("text/html");
			PrintWriter writer = response.getWriter();

			writer.print("<p><a href='" + response.createActionURL() + "'>"
					+ "Remote controller Modeshape</a></p>");

			//
			writer.close();
		}
	}

	@Override
	public void processAction(ActionRequest request, ActionResponse response)
			throws PortletException, IOException {

		Server server = new Server("http://localhost:8080", "username", "password");
		Repository repository = new Repository("Cars", server);
		Workspace workspace = new Workspace("workspace1", repository);

		IRestClient restClient = new JsonRestClient();
		try {
			List<QueryRow> rows = restClient.query(workspace, "xpath", "//*");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void printAllNodes(Node root, String space)
			throws RepositoryException {
		NodeIterator nodeIterator = (NodeIterator) root.getNodes();
		while (nodeIterator.hasNext()) {
			Node node = (Node) nodeIterator.nextNode();
			System.out.println(space + node);
			System.out.println();
			PropertyIterator pi = node.getProperties();
			while (pi.hasNext()) {
				Property property = pi.nextProperty();
				System.out
						.println(space
								+ "------------------------------------------------------");
				System.out.print(space + property.getName() + " - ");
				try {
					System.out.println(property.getValue().getString());
				} catch (ValueFormatException e) {
					for (Value value : property.getValues())
						System.out.print(value.getString() + " - ");
					System.out.println();
				}
			}
			printAllNodes(node, space + "   ");
		}
	}
}