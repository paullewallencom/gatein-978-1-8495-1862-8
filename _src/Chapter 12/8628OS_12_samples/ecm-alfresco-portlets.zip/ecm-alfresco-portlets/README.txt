This examples are provided to show how you can integrate Alfresco and GateIn when both are installed in the same application server.

1. Copy the portlet snippet inside the alfresco.war/WEB-INF/portlet.xml inside the the portlet.xml of your Alfresco application
2. Copy all the WebScripts in your Alfresco extensionRoot folder
3. Start the application server
4. From GateIn, go in the Application Registry of the portal and browse portlets, now create a new portlet instance
5. Create a new page in the portal and add the new Alfresco portlet